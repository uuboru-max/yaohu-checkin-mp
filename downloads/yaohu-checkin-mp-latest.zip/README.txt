腰护打卡 · 微信小程序

1. 注册：https://mp.weixin.qq.com  → 小程序（个人主体即可）
   类目选「工具」或「生活服务」，不要选医疗。
2. 下载「微信开发者工具」：https://developers.weixin.qq.com/miniprogram/dev/devtools/download.html
3. 导入本文件夹。project.config.json 里 appid 先用 touristappid 可预览。
4. 把你的小程序 AppID 填进 project.config.json 的 appid。
5. 开发者工具：预览 → 手机扫码。正式上线点「上传」再在公众平台提交审核。

个人主体可以发工具类小程序。文案保持「打卡 / 非医疗诊断」。
变现以后用：按钮跳转你的知识付费链接或加企微，不要在小程序里写疗效。
