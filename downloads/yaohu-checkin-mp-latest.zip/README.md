# 腰护打卡 · 微信小程序

Download this repo as a zip:

**https://github.com/uuboru-max/yaohu-checkin-mp/archive/refs/heads/main.zip**

1. Unzip.
2. WeChat DevTools → 导入 → select the folder that contains `app.json`.
3. AppID: 测试号 / touristappid.
4. Preview.

Category: 工具. Not a medical product.
